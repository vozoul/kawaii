 voici l'URL du repository GitHub nomm� "formulaire" que j'ai cr�� pour cette activit� : https://github.com/cultureweb/formulaire

Creation d'un simple formulaire 

first commit avec fichier index.html
structure html du formulaire
ajout du css
modification du titre en css



